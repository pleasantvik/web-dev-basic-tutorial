const inputEl = document.querySelector("input");
const light = document.querySelector("body");
const highlight = document.querySelectorAll(".highlight");
const card = document.querySelectorAll(".card");

// inputEl.addEventListener("click", () => {
//   if (light.classList.contains("light")) {
//     light.classList.remove("light");
//     highlight.forEach((el) => el.classList.remove("light"));
//     card.forEach((el) => el.classList.remove("light"));
//   } else {
//     light.classList.add("light");
//     card.forEach((el) => el.classList.add("light"));

//     highlight.forEach((el) => el.classList.add("light"));
//   }
// });
